<template>
  <div>
    HelloDoc帮助文档
  </div>
</template>
<script type="text/ecmascript-6">
export default {
    data(){
        return {}
    }
}
</script>
