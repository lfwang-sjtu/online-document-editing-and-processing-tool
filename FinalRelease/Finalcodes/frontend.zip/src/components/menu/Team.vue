<template>
  <div>
    这是第一个页面
    <memberList> </memberList>
  </div>
</template>
<script type="text/ecmascript-6">
import memberList from '../team/memberList';
    export default {
        data(){
            return {}
        },
        components:{
            memberList
        },
    }
</script>
