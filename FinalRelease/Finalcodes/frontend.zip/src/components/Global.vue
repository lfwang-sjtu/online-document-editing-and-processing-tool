<script type="text/javascript">
const colorList = [];
const loginStatus = false;
const token = "";
const username = "not login";
const email = "test@example.com";
/*const my_book_comments={};
const my_movie_comments={};
const my_groups={};
const my_topics={};
const my_movie_reports={};
const my_book_reports={};
*/
/*function getStatus () {

}*/
export default {
  colorList,
  loginStatus,
  token,
  username,
  email
  /*my_book_comments,
  my_movie_comments,
  my_groups,
  my_topics,
  my_movie_reports,
  my_book_reports,
  */
};
</script>
