<template>
  <div>
    <a-layout-footer
      style="width:100%;text-align:center;background: rgb(240,242,245)"
    >
      <p style="color:rgb(184,189,196);margin-top:10px"></p>
    </a-layout-footer>
  </div>
</template>

<style>
.footer {
  position: absolute;
  text-align: center;
  bottom: 0;
  width: 100%;
  background: rgb(240, 242, 245);
}
</style>
